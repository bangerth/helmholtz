this is a complemtary set of files from the ones on aug 25.
The aug 25 files had U=0 at x=L, which would be a closed volume.
These are for P=0 at x=L, which is an open flow through channel.


this solution is for a 5x5mm rectangular duct that's 10mm long.
highly damped values for rho and B for a 0.2mm high slot were used.

it has two ports with the ares modeler setting P=0 at L=10mm, so it'll act as a flow through channel.

The low frequency impedance into a sealed volume well estimated by

Z = P (Pa) / U (m^3/s) = jw*rho*L/S

where S is the surface area of the port (5mmx5mm = 25mm^2 or 25e-6 m^2)

A screen capture of the impedance into the volume is in "Ares impedance solution.jpg"


The data from the impedance is in the file "Ares impedance solution.txt".  It's listed as columns of frequency real part, frequency imaginary part, etc.

The helmholtz prm data and solution files are in the directory "E1_REHTJBPPPFRBOYZW".

The Gmsh file that generated the mesh file for the helmholtz solution is "make narrow slot.geo".

The pressure at the input of the channel is 1 Pa.


At the enterance (x=0)
P=1  
"V at x=0.txt"    gives the real and imaginary parts of the particle velocity (m/s) at x=0
                  the direction of the velocity is from the pressure side (P=1) towards the pressure release side (P=0)

data giving the pressure and velocity solutions from the Ares modeler are given in text files.  since the duct is 10mm long, half way is x=5mm, and the far end is x=10mm.

At the mid point (x=5mm)
"P at x=5mm.txt"     gives the real and imaginary parts of the pressure (Pa) at x=5mm
"V at x=5mm.txt"     gives the real and imaginary parts of the particle velocity (m/s) at x=5mm
                     the direction of the velocity is from the pressure side (P=1) towards the pressure release side (P=0)


At the ridig termination end (x=10mm)
P=0
"V at x=10mm.txt"     gives the real and imaginary parts of the particle velocity OUT of the channel (m/s) at x=10mm
