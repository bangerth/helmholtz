this solution is for a 5x5mm rectangular duct that's 10mm long.
it only has one port so it'll act as a sealed volume.

The impedance into a sealed volume is

Z = P (Pa) / U (m^3/s) = B/(jw*volume)


A screen capture of the impedance into the volume is in "Ares impedance solution.jpg"

The data from the impedance is in the file "Ares impedance solution.txt".  It's listed as columns of frequency real part, frequency imaginary part, etc.


The helmholtz prm data and solution files are in the directory "E1_IRTHRTGJPTYQZLUV".

The Gmsh file that generated the mesh file for the helmholtz solution is "make narrow slot.geo".

The pressure at the input of the volume is 1 Pa.


data giving the pressure and velocity solutions from the Ares modeler are given in text files.  since the duct is 10mm long, half way is x=5mm, and the far end is x=10mm.

At the enterance (x=0)
P=1  
"V at x=0.txt"    gives the real and imaginary parts of the particle velocity (m/s) at x=0


At the mid point (x=5mm)
"P at x=5mm.txt"     gives the real and imaginary parts of the pressure (Pa) at x=5mm
"V at x=5mm.txt"     gives the real and imaginary parts of the particle velocity (m/s) at x=5mm


At the ridig termination end (x=10mm)
"P at x=10mm.txt"     gives the real and imaginary parts of the pressure (Pa) at x=10mm
V=0